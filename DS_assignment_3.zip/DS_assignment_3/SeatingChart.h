#ifndef SEATING_CHART_H
#define SEATING_CHART_H

#include <vector>
#include <memory>
#include "Student.h"

using namespace std;


struct SeatingChart {
private:
    vector<vector<unique_ptr<Student>>> seats;

public:
    SeatingChart(int rows, int cols);
    void assignStudent(int row, int col, const string& name, int id);
    void printChart() const;
};

#endif