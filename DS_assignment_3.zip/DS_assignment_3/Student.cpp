
#include "Student.h"

using namespace std;

Student::Student(const string& name, int id) : name(name), id(id) {}

string Student::getName() const {
    return name;
}

int Student::getID() const {
    return id;
}
