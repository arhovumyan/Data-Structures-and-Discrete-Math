//
// Created by Aro Hov on 6/11/25.
//
#include "SeatingChart.h"

int main() {
    SeatingChart chart(2, 3);
    chart.assignStudent(0, 0, "Alice", 101);
    chart.assignStudent(0, 1, "Ando", 102);
    chart.assignStudent(1, 2, "Bob", 103);
    chart.printChart();
    return 0;
}