
#ifndef STUDENT_H
#define STUDENT_H

#include <string>
using namespace std;

struct Student {
private:
    string name;
    int id;

public:
    Student(const string& name, int id);
    string getName() const;
    int getID() const;
};

#endif 