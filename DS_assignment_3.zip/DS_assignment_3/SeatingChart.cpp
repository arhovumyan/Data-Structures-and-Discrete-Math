#include "SeatingChart.h"
#include <iostream>

using namespace std;

SeatingChart::SeatingChart(int rows, int cols) {
    seats.resize(rows);
    for (auto& row : seats) {
        row.resize(cols);
    }
}

void SeatingChart::assignStudent(int row, int col, const string& name, int id) {
    if (row >= 0 && row < seats.size() && col >= 0 && col < seats[0].size()) {
        seats[row][col] = make_unique<Student>(name, id);
    }
}

void SeatingChart::printChart() const {
    for (int i = 0; i < seats.size(); ++i) {
        for (int j = 0; j < seats[i].size(); ++j) {
            if (seats[i][j]) {
                cout << seats[i][j]->getName() << " (" << seats[i][j]->getID() << ")\t";
            } else {
                cout << "[Empty]\t";
            }
        }
        cout << '\n';
    }
}
